# SwiftData conversion

- `Models/Entities.swift` (new): database tables ProductEntity, RentalEntity (linked to its product), ActivityEntity, ProfileEntity.
- `AppData.swift`: now stores everything in a SwiftData database instead of UserDefaults. Public API unchanged, so no view was edited.
- First launch after the update copies any old UserDefaults data into the database (or loads the sample data). After that the database is the source of truth.
- Views still use the plain Product / Rental / Profile structs from Models.swift.
