import SwiftUI
import Combine

import SwiftData

// MARK: - Legacy storage (old UserDefaults data, read once for migration)

private enum LegacyStore {
    static func load<T: Decodable>(_ key: String) -> T? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(T.self, from: data)
    }
}

// MARK: - AppData (backed by a SwiftData / SQLite database on the device)

@MainActor
final class AppData: ObservableObject {

    private static let seededKey = "gr_swiftdata_seeded"

    let container: ModelContainer
    private var context: ModelContext { container.mainContext }

    @Published var products: [Product] {
        didSet { syncProducts() }
    }

    @Published var rentals: [Rental] {
        didSet { syncRentals() }
    }

    @Published var activityIds: [String] {
        didSet { syncActivity() }
    }

    @Published var profile: Profile {
        didSet { syncProfile() }
    }

    init(inMemory: Bool = false) {
        let schema = Schema([
            ProductEntity.self, RentalEntity.self,
            ActivityEntity.self, ProfileEntity.self
        ])
        let config = ModelConfiguration(schema: schema, isStoredInMemoryOnly: inMemory)
        let container: ModelContainer
        do {
            container = try ModelContainer(for: schema, configurations: [config])
        } catch {
            fatalError("Could not create the GadgRents database: \(error)")
        }
        let ctx = container.mainContext
        let alreadySeeded = inMemory ? false : UserDefaults.standard.bool(forKey: Self.seededKey)

        let loadedProducts: [Product]
        let loadedRentals: [Rental]
        let loadedActivity: [String]
        let loadedProfile: Profile

        if alreadySeeded {
            // Normal launch: read everything back from the database.
            let p = (try? ctx.fetch(FetchDescriptor<ProductEntity>(sortBy: [SortDescriptor(\.sortIndex)]))) ?? []
            let r = (try? ctx.fetch(FetchDescriptor<RentalEntity>(sortBy: [SortDescriptor(\.sortIndex)]))) ?? []
            let a = (try? ctx.fetch(FetchDescriptor<ActivityEntity>(sortBy: [SortDescriptor(\.sortIndex)]))) ?? []
            let pr = (try? ctx.fetch(FetchDescriptor<ProfileEntity>())) ?? []
            loadedProducts = p.map { $0.asProduct }
            loadedRentals = r.map { $0.asRental }
            loadedActivity = a.map { $0.rentalId }
            loadedProfile = pr.first?.asProfile ?? Profile()
        } else {
            // First launch with the database: bring over old UserDefaults data if any,
            // otherwise start from the sample data.
            let seededRentals = Seed.rentals
            loadedProducts = LegacyStore.load("gr_products") ?? Seed.products
            loadedRentals = LegacyStore.load("gr_rentals") ?? seededRentals
            loadedActivity = LegacyStore.load("gr_activity") ?? seededRentals.map { $0.id }
            loadedProfile = LegacyStore.load("gr_profile") ?? Profile()
        }

        self.container = container
        self.products = loadedProducts
        self.rentals = loadedRentals
        self.activityIds = loadedActivity
        self.profile = loadedProfile

        if !alreadySeeded {
            // Property observers don't fire inside init, so write the first copy explicitly.
            syncProducts()
            syncRentals()
            syncActivity()
            syncProfile()
            if !inMemory { UserDefaults.standard.set(true, forKey: Self.seededKey) }
        }
    }

    // MARK: Database sync (array in memory -> rows on disk)

    private func save() {
        do { try context.save() } catch { print("GadgRents save failed: \(error)") }
    }

    private func syncProducts() {
        let existing = (try? context.fetch(FetchDescriptor<ProductEntity>())) ?? []
        var byId = Dictionary(existing.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
        for (i, p) in products.enumerated() {
            if let e = byId.removeValue(forKey: p.id) {
                e.apply(p, order: i)
            } else {
                context.insert(ProductEntity(p, order: i))
            }
        }
        for stale in byId.values { context.delete(stale) }
        save()
    }

    private func syncRentals() {
        let productRows = (try? context.fetch(FetchDescriptor<ProductEntity>())) ?? []
        let productById = Dictionary(productRows.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })

        let existing = (try? context.fetch(FetchDescriptor<RentalEntity>())) ?? []
        var byId = Dictionary(existing.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
        for (i, r) in rentals.enumerated() {
            let row: RentalEntity
            if let e = byId.removeValue(forKey: r.id) {
                e.apply(r, order: i)
                row = e
            } else {
                row = RentalEntity(r, order: i)
                context.insert(row)
            }
            row.product = productById[r.productId]
        }
        for stale in byId.values { context.delete(stale) }
        save()
    }

    private func syncActivity() {
        let existing = (try? context.fetch(FetchDescriptor<ActivityEntity>())) ?? []
        for row in existing { context.delete(row) }
        for (i, id) in activityIds.enumerated() {
            context.insert(ActivityEntity(rentalId: id, order: i))
        }
        save()
    }

    private func syncProfile() {
        let existing = (try? context.fetch(FetchDescriptor<ProfileEntity>())) ?? []
        if let row = existing.first {
            row.apply(profile)
        } else {
            context.insert(ProfileEntity(profile))
        }
        save()
    }

    // MARK: Derived values

    var activeRentals: [Rental] { rentals.filter { $0.status == .active } }
    var overdueRentals: [Rental] { rentals.filter { $0.status == .overdue } }
    var upcomingRentals: [Rental] { rentals.filter { $0.status == .upcoming } }
    var completedRentals: [Rental] { rentals.filter { $0.status == .completed } }

    /// Revenue ignores upcoming rentals (same as the prototype).
    var processedRentals: [Rental] { rentals.filter { $0.status != .upcoming } }
    var totalRevenue: Int { processedRentals.reduce(0) { $0 + $1.totalCost } }

    var availableCount: Int { products.filter { $0.available }.count }
    var uniqueCustomers: Int { Set(rentals.map { $0.customerName }).count }

    var activityRentals: [Rental] {
        activityIds.compactMap { id in rentals.first { $0.id == id } }
    }

    func rental(id: String) -> Rental? { rentals.first { $0.id == id } }
    func product(id: String) -> Product? { products.first { $0.id == id } }

    // MARK: Activity log

    private func pushActivity(_ id: String) {
        activityIds.removeAll { $0 == id }
        activityIds.insert(id, at: 0)
    }

    func removeActivity(_ id: String) {
        activityIds.removeAll { $0 == id }
    }

    func clearActivity() {
        activityIds = []
    }

    // MARK: Rentals

    func addRental(_ rental: Rental) {
        rentals.insert(rental, at: 0)
        if rental.status == .active {
            setAvailability(productId: rental.productId, available: false)
        }
        pushActivity(rental.id)
    }

    func updateRental(_ updated: Rental) {
        if let i = rentals.firstIndex(where: { $0.id == updated.id }) {
            rentals[i] = updated
        }
        pushActivity(updated.id)
    }

    func markReturned(_ id: String) {
        guard let i = rentals.firstIndex(where: { $0.id == id }) else { return }
        rentals[i].returned = true
        rentals[i].status = .completed
        setAvailability(productId: rentals[i].productId, available: true)
        pushActivity(id)
    }

    // MARK: Products

    func setAvailability(productId: String, available: Bool) {
        if let i = products.firstIndex(where: { $0.id == productId }) {
            products[i].available = available
        }
    }

    func toggleAvailability(_ id: String) {
        if let i = products.firstIndex(where: { $0.id == id }) {
            products[i].available.toggle()
        }
    }

    func addProduct(_ product: Product) {
        products.insert(product, at: 0)
    }

    func updateProduct(_ updated: Product) {
        if let i = products.firstIndex(where: { $0.id == updated.id }) {
            products[i] = updated
        }
        for i in rentals.indices where rentals[i].productId == updated.id {
            rentals[i].productName = updated.name
            rentals[i].category = updated.category
            rentals[i].pricePerDay = updated.pricePerDay
            rentals[i].totalCost = updated.pricePerDay
                * DateUtil.daysBetween(rentals[i].startDate, rentals[i].endDate)
        }
    }
}
