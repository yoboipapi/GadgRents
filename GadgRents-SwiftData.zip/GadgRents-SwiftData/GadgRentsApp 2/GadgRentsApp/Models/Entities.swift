import Foundation
import SwiftData

// MARK: - SwiftData tables
//
// These are the on-device database tables. The views keep using the plain
// `Product` / `Rental` / `Profile` structs from Models.swift; AppData converts
// between the two, so no view code had to change.

@Model
final class ProductEntity {
    @Attribute(.unique) var id: String
    var name: String
    var category: String
    var pricePerDay: Int
    var available: Bool
    var totalRentals: Int
    var rating: Double
    var productDescription: String
    var sortIndex: Int

    /// All rentals of this product. Deleting a product keeps its rentals (history).
    @Relationship(deleteRule: .nullify, inverse: \RentalEntity.product)
    var rentals: [RentalEntity] = []

    init(_ p: Product, order: Int) {
        id = p.id
        name = p.name
        category = p.category
        pricePerDay = p.pricePerDay
        available = p.available
        totalRentals = p.totalRentals
        rating = p.rating
        productDescription = p.description
        sortIndex = order
    }

    func apply(_ p: Product, order: Int) {
        name = p.name
        category = p.category
        pricePerDay = p.pricePerDay
        available = p.available
        totalRentals = p.totalRentals
        rating = p.rating
        productDescription = p.description
        sortIndex = order
    }

    var asProduct: Product {
        Product(id: id, name: name, category: category, pricePerDay: pricePerDay,
                available: available, totalRentals: totalRentals, rating: rating,
                description: productDescription)
    }
}

@Model
final class RentalEntity {
    @Attribute(.unique) var id: String
    var productId: String
    var productName: String
    var category: String
    var customerName: String
    var customerPhone: String
    var customerEmail: String
    var customerAddress: String
    var pricePerDay: Int
    var startDate: Date
    var endDate: Date
    var quantity: Int
    var totalCost: Int
    var statusRaw: String
    var note: String
    var returned: Bool
    var sortIndex: Int

    var product: ProductEntity?

    init(_ r: Rental, order: Int) {
        id = r.id
        productId = r.productId
        productName = r.productName
        category = r.category
        customerName = r.customerName
        customerPhone = r.customerPhone
        customerEmail = r.customerEmail
        customerAddress = r.customerAddress
        pricePerDay = r.pricePerDay
        startDate = r.startDate
        endDate = r.endDate
        quantity = r.quantity
        totalCost = r.totalCost
        statusRaw = r.status.rawValue
        note = r.note
        returned = r.returned
        sortIndex = order
    }

    func apply(_ r: Rental, order: Int) {
        productId = r.productId
        productName = r.productName
        category = r.category
        customerName = r.customerName
        customerPhone = r.customerPhone
        customerEmail = r.customerEmail
        customerAddress = r.customerAddress
        pricePerDay = r.pricePerDay
        startDate = r.startDate
        endDate = r.endDate
        quantity = r.quantity
        totalCost = r.totalCost
        statusRaw = r.status.rawValue
        note = r.note
        returned = r.returned
        sortIndex = order
    }

    var asRental: Rental {
        Rental(id: id, productId: productId, productName: productName, category: category,
               customerName: customerName, customerPhone: customerPhone,
               customerEmail: customerEmail, customerAddress: customerAddress,
               pricePerDay: pricePerDay, startDate: startDate, endDate: endDate,
               quantity: quantity, totalCost: totalCost,
               status: RentalStatus(rawValue: statusRaw) ?? .upcoming,
               note: note, returned: returned)
    }
}

/// One row per entry in the "recent activity" list (newest first by `sortIndex`).
@Model
final class ActivityEntity {
    var rentalId: String
    var sortIndex: Int

    init(rentalId: String, order: Int) {
        self.rentalId = rentalId
        self.sortIndex = order
    }
}

/// Single-row table for the owner's profile.
@Model
final class ProfileEntity {
    var name: String
    var emoji: String
    var role: String
    var business: String
    var location: String
    var phone: String
    var email: String
    var memberSince: String

    init(_ p: Profile) {
        name = p.name
        emoji = p.emoji
        role = p.role
        business = p.business
        location = p.location
        phone = p.phone
        email = p.email
        memberSince = p.memberSince
    }

    func apply(_ p: Profile) {
        name = p.name
        emoji = p.emoji
        role = p.role
        business = p.business
        location = p.location
        phone = p.phone
        email = p.email
        memberSince = p.memberSince
    }

    var asProfile: Profile {
        Profile(name: name, emoji: emoji, role: role, business: business,
                location: location, phone: phone, email: email, memberSince: memberSince)
    }
}
